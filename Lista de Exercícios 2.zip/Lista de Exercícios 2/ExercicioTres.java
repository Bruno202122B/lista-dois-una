import java.util.Scanner;

public class ExercicioTres {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      System.out.print("Digite o valor de a: ");
      double a = sc.nextDouble();
      
      System.out.print("Digite o valor de b: ");
      double b = sc.nextDouble();
      
      System.out.print("Digite o valor de c: ");
      double c = sc.nextDouble();
      
      double delta = (b * b) - (4 * a * c);
      
      if (a == 0 && b == 0 && c != 0) {
         System.out.println("Coeficientes informados incorretamente.");
      } else if (a == 0 && b != 0) {
         System.out.println("Essa é uma equação de primeiro grau.");
         double x = -c / b;
         System.out.println("A raiz real da equação é: " + x);
      } else if (delta < 0) {
         System.out.println("Esta equação não possui raízes reais.");
      } else if (delta == 0) {
         System.out.println("Esta equação possui duas raízes reais iguais.");
         double x = -b / (2 * a);
         System.out.println("As raízes da equação são: " + x + " e " + x);
      } else {
         System.out.println("Esta equação possui duas raízes reais diferentes.");
         double x1 = (-b + Math.sqrt(delta)) / (2 * a);
         double x2 = (-b - Math.sqrt(delta)) / (2 * a);
         System.out.println("As raízes da equação são: " + x1 + " e " + x2);
      }
      
      sc.close();
   }
}
